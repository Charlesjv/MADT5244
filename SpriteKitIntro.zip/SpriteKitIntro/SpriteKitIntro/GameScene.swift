//
//  GameScene.swift
//  SpriteKitIntro
//
//  Created by MacBook Pro on 2019-09-30.
//  Copyright © 2019 MacBook Pro. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    //MARK: Sprite node variables
    
    var highScoreLabel = SKLabelNode()
    var bg = SKSpriteNode()
    var square = SKSpriteNode()
    
    var bgDirection:String = "left"
    
    // CONSTRUCTOR  - set up your scene + sprites
    
    override func didMove(to view: SKView) {
        print("Hello World")
        
        highScoreLabel = SKLabelNode(text:"Score:25")
        highScoreLabel.position = CGPoint(x:100,y:100)
        highScoreLabel.fontSize = 45
        highScoreLabel.fontColor = UIColor.yellow
        highScoreLabel.fontName = "Avenir"
        
        // Show the node
        
        addChild(highScoreLabel)
        
    // Create the node
        // Drawing a square
        // CGSize objects = Rect object in java
         square = SKSpriteNode(color: UIColor.yellow, size: CGSize(width: 30, height: 30))
        square.position = CGPoint(x:50,y:50);
        //Configure the square
        //Add the square to the screen
        addChild(square)
        
        // Adding an image
        
        self.bg = SKSpriteNode(imageNamed: "bg.jpeg")
        self.bg.position = CGPoint(x:200, y: 500)
        addChild(self.bg);
        
        
        
        let moveUpAction = SKAction.moveBy(x: 0, y: 300, duration: 2)
        let moveRightAction = SKAction.moveBy(x: 250, y:0, duration: 2)
        let moveLeftAction = SKAction.moveBy(x: -250, y: 0, duration: 2)
        
        let animation = SKAction.sequence([moveUpAction,moveRightAction,moveLeftAction])
        
      
        let threeTimesAction = SKAction.repeat(animation, count: 3)
          square.run(threeTimesAction)
        
        let animation2 = SKAction.sequence([moveRightAction,moveLeftAction])
        
        let foreverAnimation = SKAction.repeatForever(animation2)
        highScoreLabel.run(foreverAnimation)
        // Size is a global variable that gives the width of the screen
        // size.width = this.screenwidth  same as in Android
        // size.height = this.screenheight same as in Android
        
        print("Screen size: \(size.width),\(size.height)");
    }
    
    // Built in function that runs one per frame
    
    override func update(_ currentTime: TimeInterval) {
        
        //SKAction movement
        
        bg.run(SKAction.moveTo(x: size.width, duration: 1.0)) {
            self.bg.run(SKAction.moveTo(x: 0, duration: 1.0))
        }
        
//     let moveUpAction = SKAction.moveBy(x: 0, y: 1, duration: 2)
//        let moveDownAction = SKAction.moveBy(x: 0, y: -1, duration: 2)
//
//
//        let animation = SKAction.sequence([moveUpAction,moveDownAction])
//
//        square.run(animation)
        
        // Manual movement
//        if(self.bgDirection == "right" ){
//        self.bg.position.x = self.bg.position.x + 1
//
//            if(self.bg.position.x > size.width){
//                self.bgDirection = "left"
//                //            self.bgDirection = "left
//        }
////
////
////        }
//        }
//        else if(self.bgDirection == "left"){
//             self.bg.position.x = self.bg.position.x - 1
//
//                if(self.bg.position.x < 10){
//                    self.bgDirection  = "right"
//                }
//
//            }
    
     
    }
   
    
    //Detect USER INPUT
    //----------------------------
    // touches Ended :- To know if the person lifted finger of the screen
    // touches Began :- to know if the person touched the screen
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("Person touched the screen");
        
        
        // Detect (x,y) position of where finger is
        
        let locationTouched = touches.first
        if(locationTouched == nil){
            return
        }
        
        let mousePosition = locationTouched!.location(in: self)
        print("x = \(mousePosition.x)")
        print("y = \(mousePosition.y)")
    }
}

